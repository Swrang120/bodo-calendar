-- BODO CALENDAR LIVE SYSTEM
-- Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.live_messages (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  message text not null,
  icon text default '📢',
  source text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.live_messages enable row level security;

-- Public website/app can read published messages.
drop policy if exists "public_read_active_live_messages" on public.live_messages;
create policy "public_read_active_live_messages"
on public.live_messages for select
to anon, authenticated
using (active = true);

-- Admin users are identified by app_metadata.is_admin = true.
drop policy if exists "admin_select_all_live_messages" on public.live_messages;
create policy "admin_select_all_live_messages"
on public.live_messages for select
to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'is_admin') = 'true');

drop policy if exists "admin_insert_live_messages" on public.live_messages;
create policy "admin_insert_live_messages"
on public.live_messages for insert
to authenticated
with check ((auth.jwt() -> 'app_metadata' ->> 'is_admin') = 'true');

drop policy if exists "admin_update_live_messages" on public.live_messages;
create policy "admin_update_live_messages"
on public.live_messages for update
to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'is_admin') = 'true')
with check ((auth.jwt() -> 'app_metadata' ->> 'is_admin') = 'true');

drop policy if exists "admin_delete_live_messages" on public.live_messages;
create policy "admin_delete_live_messages"
on public.live_messages for delete
to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'is_admin') = 'true');

create index if not exists live_messages_created_at_idx on public.live_messages(created_at desc);
create index if not exists live_messages_active_idx on public.live_messages(active);

create or replace function public.set_live_message_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

drop trigger if exists trg_live_message_updated_at on public.live_messages;
create trigger trg_live_message_updated_at
before update on public.live_messages
for each row execute function public.set_live_message_updated_at();

insert into public.live_messages(title,message,icon,source)
values
('Bodo Calendar Live System','Live message system is active. New cultural updates can be published here and shared with the website and future app.','📢','Bodo Calendar')
on conflict do nothing;

-- After creating your admin Auth user, set its app_metadata:
-- In a trusted server/admin environment:
-- update auth.users set raw_app_meta_data = coalesce(raw_app_meta_data,'{}'::jsonb) || '{"is_admin":true}'::jsonb where email='YOUR-ADMIN-EMAIL';
-- Do NOT run that statement from the browser.
