const CACHE = "bodo-calendar-v10";
const CORE = [
  "./",
  "./index.html",
  "./css/style.css?v=10.1",
  "./js/backend-config.js?v=10.1",
  "./js/app.js?v=10.1",
  "./js/live-system.js?v=10.1",
  "./manifest.json",
  "./data/live-updates.json",
  "./1735633-bagrumba.jpg",
  "./bodo-aronai.jpg",
  "./icon-192.png",
  "./icon-512.png"
];
self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE)
      .then(cache => cache.addAll(CORE))
      .then(() => self.skipWaiting())
  );
});
self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(k => k !== CACHE).map(k => caches.delete(k))
    )).then(() => self.clients.claim())
  );
});
self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  if (event.request.url.includes("/data/live-updates.json")) return;
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        const clone = response.clone();
        caches.open(CACHE).then(cache => cache.put(event.request, clone));
        return response;
      }).catch(() => caches.match("./index.html"));
    })
  );
});
