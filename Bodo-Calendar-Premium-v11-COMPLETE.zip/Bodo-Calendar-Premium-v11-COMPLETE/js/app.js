/* BODO CALENDAR APP — v9 */
"use strict";
(() => {
const $=id=>document.getElementById(id);
const esc=v=>String(v??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");
const data=window.BodoCalendarData;
const months=()=>data?.months||[];
let currentMonthId=0,currentMonthYear=new Date().getFullYear(),selectedDate=new Date(),deferredPrompt=null;

function clean(d){const x=new Date(d);return new Date(x.getFullYear(),x.getMonth(),x.getDate())}
function key(d){const x=clean(d);return `${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,"0")}-${String(x.getDate()).padStart(2,"0")}`}
function addDays(d,n){const x=clean(d);x.setDate(x.getDate()+n);return x}
function fmt(d,opt={day:"numeric",month:"short",year:"numeric"}){return new Intl.DateTimeFormat("en-GB",opt).format(d)}
function bodoInfo(d){return data?.getBodoDateInfo(clean(d))||null}
function eventList(d){const i=bodoInfo(d);if(!i)return[];try{if(typeof window.getBodoEvents==="function")return window.getBodoEvents(i.monthId,i.day)||[];}catch{};return[]}
function notes(d){try{return window.getNotesForDate?window.getNotesForDate(key(d)):[]}catch{return[]}}
function toast(m){const c=$("toastContainer");if(!c)return;const e=document.createElement("div");e.className="toast";e.textContent=m;c.appendChild(e);setTimeout(()=>e.remove(),3500)}

function init(){
 const today=clean(new Date());selectedDate=today;
 const i=bodoInfo(today);if(i){currentMonthId=i.monthId;currentMonthYear=i.year}
 $("copyrightYear").textContent=new Date().getFullYear();
 bind();
 renderAll();
 setTimeout(()=>document.body.classList.add("ready"),150);
}

function bind(){
 $("prevMonthBtn")?.addEventListener("click",()=>move(-1));
 $("nextMonthBtn")?.addEventListener("click",()=>move(1));
 $("todayBtn")?.addEventListener("click",()=>{selectedDate=clean(new Date());const i=bodoInfo(selectedDate);if(i){currentMonthId=i.monthId;currentMonthYear=i.year}renderAll()});
 $("monthSelect")?.addEventListener("change",e=>{currentMonthId=Number(e.target.value);const ds=data.getBodoMonthDates(currentMonthId,currentMonthYear);if(ds[0])selectedDate=ds[0];renderAll()});
 $("closeWelcomeBtn")?.addEventListener("click",()=>{$("welcomeCard")?.classList.add("hidden");localStorage.setItem("bodoWelcomeClosed","1")});
 if(localStorage.getItem("bodoWelcomeClosed")==="1")$("welcomeCard")?.classList.add("hidden");
 $("openNotesBtn")?.addEventListener("click",openNotesList);
 $("closeNotesListBtn")?.addEventListener("click",()=>hide("notesListModal"));
 $("closeDateModalBtn")?.addEventListener("click",()=>hide("dateModal"));
 $("closeDateModalBottomBtn")?.addEventListener("click",()=>hide("dateModal"));
 $("addNoteFromDateBtn")?.addEventListener("click",()=>{hide("dateModal");openNote(selectedDate)});
 $("closeNoteModalBtn")?.addEventListener("click",()=>hide("noteModal"));
 $("cancelNoteBtn")?.addEventListener("click",()=>hide("noteModal"));
 $("noteForm")?.addEventListener("submit",saveNoteForm);
 window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;$("installAppBtn")?.classList.remove("hidden")});
 $("installAppBtn")?.addEventListener("click",async()=>{if(!deferredPrompt){toast("Browser install option is available from the browser menu.");return}deferredPrompt.prompt();try{await deferredPrompt.userChoice}catch{}deferredPrompt=null;$("installAppBtn")?.classList.add("hidden")});
 $("refreshLiveBtn")?.addEventListener("click",()=>window.BodoLiveSystem?.load?.());
}

function hide(id){$(id)?.classList.add("hidden")}
function show(id){$(id)?.classList.remove("hidden")}

function move(dir){
 currentMonthId+=dir;
 if(currentMonthId<0){currentMonthId=11;currentMonthYear--}
 if(currentMonthId>11){currentMonthId=0;currentMonthYear++}
 const ds=data.getBodoMonthDates(currentMonthId,currentMonthYear);if(ds[0])selectedDate=ds[0];
 renderAll();
}

function renderAll(){
 renderSelector();renderBanner();renderWeekdays();renderGrid();renderSelected();renderEvents();renderSeason();renderReference();renderUpcoming();renderHistory();
}

function renderSelector(){
 const s=$("monthSelect");if(!s)return;s.innerHTML=months().map(m=>`<option value="${m.id}" ${m.id===currentMonthId?"selected":""}>${esc(m.name)} — ${esc(m.nativeName)}</option>`).join("");
}
function renderBanner(){
 const m=months()[currentMonthId];if(!m)return;
 $("currentMonthName").textContent=m.name;$("currentMonthNativeName").textContent=m.nativeName;
 $("monthSeasonLabel").textContent=m.season||"BODO SOLAR MONTH";
 $("currentMonthDateRange").textContent=data.getMonthRange(currentMonthId,currentMonthYear);
}
function renderWeekdays(){const h=$("weekdayHeader");if(h)h.innerHTML=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].map(x=>`<div>${x}</div>`).join("")}

function renderGrid(){
 const g=$("calendarGrid");if(!g)return;g.innerHTML="";
 const ds=data.getBodoMonthDates(currentMonthId,currentMonthYear),first=ds[0]?.getDay()||0;
 for(let i=0;i<first;i++){const e=document.createElement("div");e.className="calendar-day";e.style.visibility="hidden";g.appendChild(e)}
 ds.forEach(d=>{
   const i=bodoInfo(d), ev=eventList(d), nt=notes(d), b=document.createElement("button");
   b.type="button";b.className="calendar-day"+(key(d)===key(new Date())?" today":"")+(key(d)===key(selectedDate)?" selected":"");
   b.innerHTML=`<div class="cell-top"><span>${fmt(d,{weekday:"short"})}</span>${key(d)===key(new Date())?"📍":""}</div>
   <span class="bodo-date-number">${i?esc(i.day):""}</span>
   <span class="bodo-date-label">${i?esc(i.month.name):""}</span>
   <span class="gregorian-date-number">${d.getDate()} ${esc(fmt(d,{month:"short"}))}</span>
   ${ev.length?'<i class="event-dot"></i>':""}${nt.length?'<i class="note-dot"></i>':""}`;
   b.setAttribute("aria-label",i?`${i.month.name} ${i.day}, ${fmt(d)}`:fmt(d));
   b.addEventListener("click",()=>selectDate(d));g.appendChild(b);
 });
}
function selectDate(d){selectedDate=clean(d);const i=bodoInfo(d);if(i){currentMonthId=i.monthId;currentMonthYear=i.year}renderAll();openDate(d)}
function renderSelected(){
 const i=bodoInfo(selectedDate);if(!i)return;
 $("selectedDateTitle").textContent=`${i.month.name} ${i.day}`;
 const ev=eventList(selectedDate),nt=notes(selectedDate);
 $("selectedDateDetails").innerHTML=`<div><strong>${esc(fmt(selectedDate,{day:"numeric",month:"long",year:"numeric"}))}</strong></div>
 <div>Bodo Date: <strong>${esc(i.month.name)} ${i.day}</strong></div>
 <div>Native: <strong>${esc(i.month.nativeName)}</strong></div>
 ${ev.length?`<div>🎉 <strong>${ev.length} event${ev.length>1?"s":""}</strong></div>`:""}
 ${nt.length?`<div>📝 <strong>${nt.length} personal note${nt.length>1?"s":""}</strong></div>`:""}
 ${!ev.length&&!nt.length?"<div>No event or personal note for this date.</div>":""}`;
}
function renderEvents(){
 const c=$("eventsList");if(!c)return;const ds=data.getBodoMonthDates(currentMonthId,currentMonthYear),items=[];
 ds.forEach(d=>eventList(d).forEach(e=>items.push({d,e})));
 c.innerHTML=items.length?items.map(x=>{const i=bodoInfo(x.d);return `<div class="event-item"><strong>🎉 ${esc(x.e.title||x.e.name||"Event")}</strong><span>Bodo ${i?.day||""} • ${esc(fmt(x.d))}</span><span>${esc(x.e.desc||x.e.description||"")}</span></div>`}).join(""):`<div class="muted">No major event listed for this Bodo month.</div>`;
}
function renderSeason(){const m=months()[currentMonthId];if(!m)return;$("seasonTitle").textContent=m.season||"Bodo Season";$("seasonDescription").textContent=`${m.name} is part of the traditional Bodo solar calendar cycle.`}
function renderReference(){const b=$("monthReferenceBody");if(!b)return;b.innerHTML=months().map(m=>`<tr><td>${m.id+1}</td><td><strong>${esc(m.name)}</strong></td><td>${esc(m.nativeName)}</td><td>${esc(data.getMonthRange(m.id,currentMonthYear))}</td></tr>`).join("")}
function renderUpcoming(){
 const ds=[clean(new Date()),addDays(new Date(),1),addDays(new Date(),2)],ids=["todayAlertText","tomorrowAlertText","dayAfterTomorrowAlertText"];
 ds.forEach((d,n)=>{const i=bodoInfo(d),c=$(ids[n]);if(!c)return;c.innerHTML=i?`<div class="upcoming-bodo">${esc(i.month.name)} ${i.day}</div><div class="upcoming-eng">${esc(fmt(d))}</div><div class="muted">${eventList(d).length} event${eventList(d).length===1?"":"s"}</div>`:esc(fmt(d))});
 $("englishTodayStatus").textContent=fmt(ds[0]);const i=bodoInfo(ds[0]);$("bodoTodayStatus").textContent=i?`${i.month.name} ${i.day}`:"—";$("liveStatusUpdated").textContent=`Updated ${new Intl.DateTimeFormat("en-IN",{hour:"numeric",minute:"2-digit"}).format(new Date())}`;
}
function renderHistory(){$("historyList").innerHTML='<div class="muted">Historical entries can be added to the events/history data.</div>'}

function openDate(d){
 const i=bodoInfo(d);if(!i)return;
 $("dateModalTitle").textContent=`${i.month.name} ${i.day}`;
 const ev=eventList(d),nt=notes(d);
 $("dateModalBody").innerHTML=`<div class="note-card"><strong>🌿 Bodo Date</strong><p>${esc(i.month.name)} ${i.day} (${esc(i.month.nativeName)})</p><strong>🇬🇧 Gregorian</strong><p>${esc(fmt(d,{day:"numeric",month:"long",year:"numeric"}))}</p>${ev.map(e=>`<strong>🎉 ${esc(e.title||"Event")}</strong><p>${esc(e.desc||"")}</p>`).join("")}${nt.length?`<strong>📝 Notes: ${nt.length}</strong>`:""}</div>`;
 show("dateModal");
}
function openNote(d){$("noteDate").value=key(d);$("noteTitle").value="";$("noteDescription").value="";$("noteReminder").checked=false;show("noteModal")}
function saveNoteForm(e){e.preventDefault();if(!window.saveNote){toast("Notes module is not loaded.");return}const d=$("noteDate").value;const n=window.saveNote(d,{category:$("noteCategory").value,title:$("noteTitle").value,description:$("noteDescription").value,reminder:$("noteReminder").checked?"Important":"",});if(n){hide("noteModal");renderAll();toast("Note saved.");}}
function openNotesList(){const c=$("notesListContainer");if(!c)return;const all=window.getAllNotes?window.getAllNotes():{};const items=[];Object.entries(all).forEach(([d,list])=>list.forEach(n=>items.push({d,n})));c.innerHTML=items.length?items.map(x=>`<div class="note-card"><h4>${esc(x.n.title)}</h4><p>${esc(x.d)} • ${esc(x.n.category)}</p><p>${esc(x.n.description||"")}</p><button class="secondary-button" data-del-note="${esc(x.n.id)}" data-note-date="${esc(x.d)}">Delete</button></div>`).join(""):`<div class="muted">No notes saved yet.</div>`;c.querySelectorAll("[data-del-note]").forEach(b=>b.onclick=()=>{window.deleteNote?.(b.dataset.noteDate,b.dataset.delNote);openNotesList();renderAll()});show("notesListModal")}

if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",init,{once:true});else init();
window.BodoCalendarApp={renderAll,selectDate};
})();