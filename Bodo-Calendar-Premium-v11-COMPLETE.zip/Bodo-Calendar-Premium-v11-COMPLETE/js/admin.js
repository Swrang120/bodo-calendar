/* Secure admin client. Requires Supabase Auth + RLS configured by supabase/schema.sql */
"use strict";
(() => {
const C=window.BODO_BACKEND||{};const has=C.supabaseUrl&&C.supabaseAnonKey;
const sb=has&&window.supabase?window.supabase.createClient(C.supabaseUrl,C.supabaseAnonKey):null;
const $=id=>document.getElementById(id);
const esc=v=>String(v??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");
let editing=null;

function setStatus(x){$("loginStatus").textContent=x}
async function init(){
 if(!sb){setStatus("Backend not configured. Fill js/backend-config.js first.");return}
 const {data}=await sb.auth.getSession();if(data.session){showAdmin();await loadMessages()}else{$("loginCard").classList.remove("hidden")}
 $("loginForm").onsubmit=login;$("logoutBtn").onclick=logout;$("messageForm").onsubmit=save;$("resetMessageBtn").onclick=reset;$("researchBtn").onclick=research;
}
async function login(e){e.preventDefault();const {error}=await sb.auth.signInWithPassword({email:$("email").value,password:$("password").value});if(error){setStatus(error.message);return}showAdmin();loadMessages()}
async function logout(){await sb.auth.signOut();$("adminPanel").classList.add("hidden");$("loginCard").classList.remove("hidden")}
function showAdmin(){$("loginCard").classList.add("hidden");$("setupCard").classList.add("hidden");$("adminPanel").classList.remove("hidden")}
function reset(){editing=null;$("messageId").value="";$("messageTitle").value="";$("messageBody").value="";$("messageIcon").value="📢";$("messageSource").value="";$("messagePublished").checked=true}
async function save(e){e.preventDefault();if(!sb)return;
 const row={title:$("messageTitle").value.trim(),message:$("messageBody").value.trim(),icon:$("messageIcon").value.trim()||"📢",source:$("messageSource").value.trim()||"Bodo Calendar",active:$("messagePublished").checked};
 let q;if(editing)q=await sb.from("live_messages").update(row).eq("id",editing);else q=await sb.from("live_messages").insert(row);
 if(q.error){alert(q.error.message);return}reset();await loadMessages()
}
async function loadMessages(){
 const box=$("adminMessages");box.innerHTML="Loading…";const {data,error}=await sb.from("live_messages").select("*").order("created_at",{ascending:false}).limit(100);
 if(error){box.textContent=error.message;return}
 box.innerHTML=(data||[]).map(m=>`<div class="note-card"><h4>${esc(m.icon||"📢")} ${esc(m.title)}</h4><p>${esc(m.message)}</p><p>${esc(m.source||"")} • ${esc(m.active?"Published":"Hidden")} • ${esc(m.created_at||"")}</p><button class="secondary-button" data-edit="${esc(m.id)}">Edit</button> <button class="secondary-button" data-delete="${esc(m.id)}">Delete</button></div>`).join("")||'<p class="muted">No messages.</p>';
 box.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>edit((data||[]).find(x=>String(x.id)===b.dataset.edit)));
 box.querySelectorAll("[data-delete]").forEach(b=>b.onclick=()=>del(b.dataset.delete));
}
function edit(m){if(!m)return;editing=m.id;$("messageId").value=m.id;$("messageTitle").value=m.title||"";$("messageBody").value=m.message||"";$("messageIcon").value=m.icon||"📢";$("messageSource").value=m.source||"";$("messagePublished").checked=m.active!==false;scrollTo({top:0,behavior:"smooth"})}
async function del(id){if(!confirm("Delete this message globally?"))return;const {error}=await sb.from("live_messages").delete().eq("id",id);if(error)alert(error.message);else loadMessages()}
async function research(){
 if(!sb)return;
 const {data,error}=await sb.functions.invoke("live-research",{body:{limit:5}});
 if(error){alert("Research function: "+error.message);return}
 alert(`Research finished. ${data?.inserted||0} update(s) added.`);loadMessages()
}
init();
})();