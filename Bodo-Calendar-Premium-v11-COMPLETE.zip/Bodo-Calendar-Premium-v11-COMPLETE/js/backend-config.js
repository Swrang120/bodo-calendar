/* =========================================================
   BODO CALENDAR — PUBLIC SUPABASE CONFIG
   v10.0

   IMPORTANT:
   This file may contain ONLY the public publishable/anon key.
   NEVER put a service_role/secret key in this file.
   ========================================================= */

window.BODO_BACKEND = {
  supabaseUrl: "https://rwqecmerqyxvgdewfsrv.supabase.co",
  supabaseAnonKey: "sb_publishable_KzTjI1ao6jTf0MKNTSD6JQ_Iigfvhrx"
};

window.BODO_LIVE_API_URL = "";
