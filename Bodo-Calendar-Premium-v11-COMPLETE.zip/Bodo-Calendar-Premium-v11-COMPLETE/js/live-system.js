/* BODO CALENDAR LIVE SYSTEM v10 */
"use strict";
(() => {
const LOCAL="./data/live-updates.json";
const DISMISSED="bodo_calendar_dismissed_live_v9";
const $=id=>document.getElementById(id);
const esc=v=>String(v??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");
const getDismissed=()=>{try{return new Set(JSON.parse(localStorage.getItem(DISMISSED)||"[]"))}catch{return new Set()}};
const saveDismissed=s=>{try{localStorage.setItem(DISMISSED,JSON.stringify([...s]))}catch{}};
const time=v=>{const d=new Date(v);return Number.isNaN(d.getTime())?"":new Intl.DateTimeFormat("en-IN",{day:"numeric",month:"short",year:"numeric",hour:"numeric",minute:"2-digit"}).format(d)};

async function fetchFeed(){
 const cfg=window.BODO_BACKEND||{};
 if(cfg.supabaseUrl&&cfg.supabaseAnonKey){
   const url=cfg.supabaseUrl.replace(/\/$/,"")+"/rest/v1/live_messages?select=id,title,message,icon,source,active,created_at,updated_at&active=eq.true&order=created_at.desc&limit=20";
   const r=await fetch(url,{headers:{apikey:cfg.supabaseAnonKey,Authorization:`Bearer ${cfg.supabaseAnonKey}`},cache:"no-store"});
   if(!r.ok)throw new Error("Supabase feed unavailable");
   return {messages:await r.json(),shared:true};
 }
 const r=await fetch(LOCAL+"?_"+Date.now(),{cache:"no-store"});if(!r.ok)throw new Error("local feed unavailable");
 const raw=await r.json();return {messages:Array.isArray(raw)?raw:(raw.messages||[]),shared:false};
}

async function load(){
 const status=$("liveUpdatesStatus"),list=$("liveUpdatesList"),empty=$("liveEmpty");if(!list)return;
 try{
  status.textContent="Updating…";
  const feed=await fetchFeed(),dismissed=getDismissed();
  const visible=feed.messages.filter(x=>x&&x.id&&!dismissed.has(String(x.id))&&x.active!==false)
    .sort((a,b)=>new Date(b.created_at||b.date||0)-new Date(a.created_at||a.date||0)).slice(0,20);
  list.innerHTML=visible.map(m=>`<article class="live-update"><div class="live-update-icon">${esc(m.icon||"📢")}</div><div><h3>${esc(m.title||"Bodo Calendar Update")}</h3><p>${esc(m.message||"")}</p><time>${esc(time(m.created_at||m.date))}${m.source?` • ${esc(m.source)}`:""}</time></div><button class="dismiss-btn" type="button" data-dismiss="${esc(m.id)}" aria-label="Dismiss on this device" title="Hide on this device">×</button></article>`).join("");
  empty.classList.toggle("hidden",visible.length>0);
  $("liveSystemInfo")?.classList.remove("hidden");
  $("liveSystemInfoText").textContent=feed.shared
    ?"Shared Supabase feed connected. Admin changes appear here and can be reused by the future app."
    :"Local fallback feed active. Add Supabase config for shared admin + automatic research.";
  list.querySelectorAll("[data-dismiss]").forEach(b=>b.onclick=()=>{const s=getDismissed();s.add(String(b.dataset.dismiss));saveDismissed(s);load()});
  status.textContent=`${visible.length} live update${visible.length===1?"":"s"} • refreshed ${new Intl.DateTimeFormat("en-IN",{hour:"numeric",minute:"2-digit"}).format(new Date())}`;
 }catch(e){
  status.textContent="Live feed unavailable — check backend settings.";
  empty.classList.remove("hidden");
  console.warn("Bodo Live:",e);
 }
}
window.BodoLiveSystem={load};
const refresh=document.getElementById("refreshLiveBtn"); if(refresh) refresh.addEventListener("click",load);
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",()=>{load();setInterval(load,300000)},{once:true});else{load();setInterval(load,300000)}
})();